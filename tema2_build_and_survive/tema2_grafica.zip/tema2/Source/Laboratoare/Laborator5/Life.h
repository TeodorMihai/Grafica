#pragma once

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>


#include "GameObject.h"
class Life : public GameObject {

public:

	Life();

};
