#include "Animation.h"

Animation::Animation() { }

Animation::Animation(string name) : name(name) { }
Animation::~Animation() { }