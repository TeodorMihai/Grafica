#include "Sprite.h"

Sprite::Sprite(){ }
Sprite::Sprite(int width, int height) : width(width), height(height) { }
Sprite::~Sprite() { }

