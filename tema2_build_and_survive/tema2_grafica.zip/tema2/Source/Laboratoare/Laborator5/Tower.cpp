#pragma once

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

#include "Tower.h"
Tower::Tower() : GameObject("tower", "box", "VertexNormal") { }
