#pragma once

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

#include "Life.h"
Life::Life() : GameObject("sphere", "", "Simple") { }
